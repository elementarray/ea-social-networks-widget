<?php
namespace EA_Social_Networks_Widget\Core;
use EA_Social_Networks_Widget\Interfaces as Interfaces;
abstract class Abstract_WP_Widget implements Interfaces\Interface_WP_Widget {
    /**
     * @var array 
     */
    protected $widget_options;
    /**
     * @var string 
     */
    protected $id_base;
    /**
     * @var string 
     */
    protected $name;
    /**
     * @var array 
     */
    protected $control_options;
    /**
     * @var bool 
     */
    protected $number = false;
    /**
     * @var bool
     */
    protected $id = false;
    /**
     * @var bool 
     */
    protected $updated = false;
 
    /**
     * Constructor
     *
     * @param type $id_base
     * @param type $name
     * @param type $widget_options
     * @param type $control_options
     */
    public function __construct( $id_base, $name, $widget_options = array(), $control_options = array() )
    {
    }
 
    /**
     * {@inheritdoc}
     */
    final public function register()
    {
    }
 
    /**
     * Generate the actual widget content.
     */
    final public function display_callback($args, $widget_args = 1)
    {
    }
 
    /**
     * Generate the control form.
     */
    final public function form_callback($widget_args = 1)
    {
    }
 
    /**
     * Deal with changed settings.
     *
     * @param mixed $deprecated Not used.
     */
    final public function update_callback($deprecated = 1)
    {
    }
 
    /**
     * Echo the settings update form.
     *
     * @param array $instance Current settings
     */
    protected function form($instance)
    {
    }
 
    /**
     * Constructs name attributes for use in form() fields.
     *
     * @param string $field_name
     * 
     * @return string
     */
    protected function get_field_name($field_name) {
    }
 
    /**
     * Constructs id attributes for use in form() fields.
     *
     * @param string $field_name
     * 
     * @return string
     */
    protected function get_field_id($field_name) {
    }
 
    /**
     * Update a widget instance.
     *
     * @param array $new_instance
     * @param array $old_instance
     *
     * @return array
     */
    protected function update($new_instance, $old_instance)
    {
    }
}