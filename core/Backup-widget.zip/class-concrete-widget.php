<?php
namespace EA_Social_Networks_Widget\Core;
class Concrete_Widget extends Abstract_WP_Widget{
    public function __construct( $id_base, $name, $widget_options = array(), $control_options = array()  ){
	$this->id_base=$id_base;
	$this->name=$name;
	$this->widget_options=$widget_options; 
	$this->control_options=$control_options;
	}
/**
    final public function register() { }

    final public function display_callback($args, $widget_args = 1){
	$this->args=$args; 
	$this->widget_args=$widget_args;
	}
 
    final public function form_callback($widget_args = 1){
	$this->widget_args=$widget_args;
	}
 
    final public function update_callback($deprecated = 1){
		$this->deprecated=$deprecated;
	}
**/
    protected function form($instance){
	$this->instance=$instance;
	}
 
    protected function get_field_name($field_name) {
	$this->field_name=$field_name;
	}
 
    protected function get_field_id($field_id) {
	$this->field_id=$field_id;
	}

    protected function update($new_instance, $old_instance){
	$this->old_instance=$old_instance;
	$this->new_instance=$new_instance;
	}
}