<?php
// class-plugin-api-manager.php
namespace EA_Social_Networks_Widget\Core;
//use EA_Social_Networks_Widget as NS;
/**
The goal is to create a class that will handle registering actions and/or filters for any class. 
Eliminating the need for you to handle it in each of your classes.
The main entry point is going to be the register method. Passing an object to that method will register it with the plugin API
**/

//class Plugin_API_Manager{}


class Plugin_API_Manager{

    public function register($object){
        if ($object instanceof Action_Hook_Subscriber) {
            $this->register_actions($object);
        }
        if ($object instanceof Filter_Hook_Subscriber) {
            $this->register_filters($object);
        }
    }

    private function register_action(Action_Hook_Subscriber $object, $name, $parameters){
        if (is_string($parameters)) {
            add_action($name, array($object, $parameters));
        } elseif (is_array($parameters) && isset($parameters[0])) {
            add_action($name, array($object, $parameters[0]), isset($parameters[1]) ? $parameters[1] : 10, isset($parameters[2]) ? $parameters[2] : 1);
        }
    }

    private function register_actions(Action_Hook_Subscriber $object){
        foreach ($object->get_actions() as $name => $parameters) {
            $this->register_action($object, $name, $parameters);
        }
    }

    private function register_filter(Filter_Hook_Subscriber $object, $name, $parameters){
        if (is_string($parameters)) {
            add_filter($name, array($object, $parameters));
        } elseif (is_array($parameters) && isset($parameters[0])) {
            add_filter($name, array($object, $parameters[0]), isset($parameters[1]) ? $parameters[1] : 10, isset($parameters[2]) ? $parameters[2] : 1);
        }
    }

    private function register_filters(Filter_Hook_Subscriber $object){
        foreach ($object->get_filters() as $name => $parameters) {
            $this->register_filter($object, $name, $parameters);
        }
    }
}
