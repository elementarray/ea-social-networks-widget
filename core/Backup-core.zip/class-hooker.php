<?php
// class-hooker.php
namespace EA_Social_Networks_Widget\Core;
use EA_Social_Networks_Widget\Interfaces as Interfaces;
use EA_Social_Networks_Widget\Admin as Admin;
//use EA_Social_Networks_Widget as NS;


//class Hooker{}
// https://carlalexander.ca/polymorphism-wordpress-interfaces/
// https://carlalexander.ca/designing-class-wordpress-hooks/

class Hooker implements Interfaces\interface_Action_Hook_Subscriber, Interfaces\interface_Filter_Hook_Subscriber{

    public function __construct(){ $this->define_admin_hooks(); }

    public static function get_actions(){
	return array( 
		'plugins_loaded' => 'on_plugins_loaded',
		//'admin_menu'	=>	array( 'AdminPage', 'my_admin_menu' ) 
	 );
	
    }
 
    public static function get_filters() {
        return array( 'the_title' => 'alter_title');
    }
 
    public function alter_title($title){
        $title .= " + extra verbage";
        return $title;
    }
 
    public function on_plugins_loaded() { }// Do something useful

    public function define_admin_hooks() {
		$plugin_admin = new Admin\AdminPage(array('option1')); // ( $this->get_plugin_name(), $this->get_version(), $this->get_plugin_text_domain() );	
/**
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_ea_taxonomy_menu' ); // defined in Admin{}	
**/
	}

}

