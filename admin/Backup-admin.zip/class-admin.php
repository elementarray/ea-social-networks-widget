<?php
// https://carlalexander.ca/polymorphism-wordpress-abstract-classes/
// class-admin.php
namespace EA_Social_Networks_Widget\Admin;
use EA_Social_Networks_Widget as NS;


// https://codex.wordpress.org/Creating_Options_Pages
// https://codex.wordpress.org/Settings_API
// abstract class AbstractAdminPage
abstract class Admin { 

	private $plugin_name;
	private $version;
	private $plugin_text_domain;

    	//@var array
    	private $options;
 
    // Register admin page WordPress hooks.
    public static function register(){
        $page = new static(get_option('my_plugin_options', array()));
        add_action('admin_init', array($page, 'configure'));
        add_action('admin_menu', array($page, 'add_admin_page'));
    }
 
    public function __construct(array $options){ $this->options = $options; }
 
    // Add admin page to the menu
    public function add_admin_page() {
        add_options_page($this->get_page_title(), $this->get_page_title(), 'install_plugins', $this->get_menu_slug(), array($this, 'render'));
    }
 
    // Configure admin page using settings API
    abstract public function configure();
 
    // Render admin page
    abstract public function render();
 
    // Render a form field
    protected function render_form_field($id, $name, $value = '', $type = 'text')
    {
        ?>
        <input id="<?php echo $id; ?>" name="<?php echo $name; ?>" type="<?php echo $type; ?>" value="<?php echo $value; ?>" />
        <?php
    }
 
    // Get admin page menu slug
    abstract protected function get_menu_slug();
 
    // Get admin page title
    abstract protected function get_page_title();
}