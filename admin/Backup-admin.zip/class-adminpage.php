<?php
namespace EA_Social_Networks_Widget\Admin;
use EA_Social_Networks_Widget as NS;

class AdminPage extends Admin{

	private $plugin_name;
	private $version;
	private $plugin_text_domain;

    	private $options;

    	// Configure admin page using settings API
    	public function configure(){
		// register_setting()
		// add_settings_section()
		// add_settings_field()
	}
 
    	// Render admin page
    	public function render(){
		// do_settings_sections()
	}

    	// Get admin page menu slug
    	protected function get_menu_slug(){}
 
    	// Get admin page title
    	protected function get_page_title(){}

	public function __construct( array $options ) {
        	$this->options = $options;
		$this->plugin_name = NS\PLUGIN_NAME;
		$this->version = NS\PLUGIN_VERSION;
		$this->plugin_text_domain = NS\PLUGIN_TEXT_DOMAIN;
	}

    	public static function register() {
        	// Create an instance of the admin page with the options
        	$page = new self(get_option('my_plugin_options', array()));
 
        	// Pass it up to the main register function
        	parent::register($page);
    	}

}